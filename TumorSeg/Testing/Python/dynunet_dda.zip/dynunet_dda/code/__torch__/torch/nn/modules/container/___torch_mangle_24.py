class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  __annotations__["0"] = __torch__.monai.networks.blocks.segresnet_block.___torch_mangle_7.ResBlock
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_24.Sequential,
    input: Tensor) -> Tensor:
    _0 = getattr(self, "0")
    return (_0).forward(input, )
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_24.Sequential) -> int:
    return 1
