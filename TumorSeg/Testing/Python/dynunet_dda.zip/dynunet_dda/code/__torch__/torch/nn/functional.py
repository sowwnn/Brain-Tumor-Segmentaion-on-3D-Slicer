def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def group_norm(input: Tensor,
    num_groups: int,
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _0 = __torch__.torch.nn.functional._verify_batch_size
  _1 = torch.mul(torch.size(input, 0), torch.size(input, 1))
  _2 = [torch.floordiv(_1, num_groups), num_groups]
  _3 = torch.list(torch.slice(torch.size(input), 2))
  _4 = _0(torch.add(_2, _3), )
  _5 = torch.group_norm(input, num_groups, weight, bias, eps)
  return _5
def interpolate(input: Tensor,
    size: Optional[int]=None,
    scale_factor: Optional[List[float]]=None,
    mode: str="nearest",
    align_corners: Optional[bool]=None,
    recompute_scale_factor: Optional[bool]=None,
    antialias: bool=False) -> Tensor:
  _6 = "align_corners option can only be set with the interpolating modes: linear | bilinear | bicubic | trilinear"
  _7 = "only one of size or scale_factor should be defined"
  _8 = "Input and scale_factor must have the same number of spatial dimensions, but got input with spatial dimensions of {} and scale_factor of shape {}. Please provide input tensor in (N, C, d1, d2, ...,dK) format and scale_factor in (s1, s2, ...,sK) format."
  _9 = "either size or scale_factor should be defined"
  _10 = "recompute_scale_factor is not meaningful with an explicit size."
  _11 = "Anti-alias option is only supported for bilinear and bicubic modes"
  _12 = __torch__.torch.nn.functional.adaptive_avg_pool2d
  _13 = __torch__.torch.nn.functional.adaptive_avg_pool3d
  _14 = "Got 3D input, but bilinear mode needs 4D input"
  _15 = "Got 3D input, but trilinear mode needs 5D input"
  _16 = "Got 4D input, but linear mode needs 3D input"
  _17 = "Got 4D input, but trilinear mode needs 5D input"
  _18 = "Got 5D input, but linear mode needs 3D input"
  _19 = "Got 5D input, but bilinear mode needs 4D input"
  _20 = "Input Error: Only 3D, 4D and 5D input Tensors supported (got {}D) for the modes: nearest | linear | bilinear | bicubic | trilinear | area | nearest-exact (got {})"
  _21 = uninitialized(Tensor)
  _22 = uninitialized(List[int])
  _23 = uninitialized(Optional[bool])
  _24 = uninitialized(NoneType)
  _25 = uninitialized(List[float])
  _26 = uninitialized(Optional[List[int]])
  _27 = uninitialized(Optional[List[float]])
  _28 = uninitialized(Optional[int])
  _29 = uninitialized(Optional[bool])
  _30 = uninitialized(bool)
  _31 = torch.__contains__(["nearest", "area", "nearest-exact"], mode)
  if _31:
    _32 = torch.__isnot__(align_corners, None)
    if _32:
      ops.prim.RaiseException(_6)
      align_corners1 : Optional[bool] = _29
    else:
      align_corners1 = align_corners
    align_corners0 : Optional[bool] = align_corners1
  else:
    if torch.__is__(align_corners, None):
      align_corners2 = False
    else:
      align_corners3 = unchecked_cast(bool, align_corners)
      align_corners2 = align_corners3
    align_corners0 = align_corners2
  dim = torch.sub(torch.dim(input), 2)
  if torch.__isnot__(size, None):
    size1 = unchecked_cast(int, size)
    _33, size0 = torch.__isnot__(scale_factor, None), size1
  else:
    _33, size0 = False, size
  if _33:
    ops.prim.RaiseException(_7)
    size2, output_size, scale_factors = _28, _26, _27
  else:
    if torch.__isnot__(size0, None):
      size4 = unchecked_cast(int, size0)
      if torch.__is__(scale_factor, None):
        pass
      else:
        ops.prim.RaiseException("AssertionError: ")
      size5 = unchecked_cast(int, size4)
      output_size1 = annotate(List[int], [])
      for _34 in range(dim):
        _35 = torch.append(output_size1, size5)
      size3, output_size0, scale_factors0 = size5, output_size1, None
    else:
      _36 = torch.__isnot__(scale_factor, None)
      if _36:
        scale_factor0 = unchecked_cast(List[float], scale_factor)
        if torch.__is__(size0, None):
          size7 : Optional[int] = size0
        else:
          ops.prim.RaiseException("AssertionError: ")
          size7 = _28
        scale_factor1 = unchecked_cast(List[float], scale_factor0)
        _37 = torch.ne(torch.len(scale_factor1), dim)
        if _37:
          _38 = torch.slice(torch.size(input), 2)
          _39 = torch.format(_8, torch.list(_38), scale_factor1)
          ops.prim.RaiseException(_39)
        else:
          pass
        size6, output_size2, scale_factors1 = size7, None, scale_factor1
      else:
        ops.prim.RaiseException(_9)
        size6, output_size2, scale_factors1 = _28, _24, _25
      size3, output_size0, scale_factors0 = size6, output_size2, scale_factors1
    size2, output_size, scale_factors = size3, output_size0, scale_factors0
  _40 = torch.__isnot__(recompute_scale_factor, None)
  if _40:
    recompute_scale_factor1 = unchecked_cast(bool, recompute_scale_factor)
    _41, recompute_scale_factor0 = recompute_scale_factor1, recompute_scale_factor1
  else:
    _41, recompute_scale_factor0 = False, recompute_scale_factor
  if _41:
    recompute_scale_factor3 = unchecked_cast(bool, recompute_scale_factor0)
    _42, recompute_scale_factor2 = torch.__isnot__(size2, None), recompute_scale_factor3
  else:
    _42, recompute_scale_factor2 = False, recompute_scale_factor0
  if _42:
    ops.prim.RaiseException(_10)
    recompute_scale_factor4 : Optional[bool] = _23
  else:
    recompute_scale_factor4 = recompute_scale_factor2
  if torch.eq(mode, "area"):
    _43 = torch.__is__(output_size, None)
  else:
    _43 = False
  if _43:
    recompute_scale_factor5 : Optional[bool] = True
  else:
    recompute_scale_factor5 = recompute_scale_factor4
  _44 = torch.__isnot__(recompute_scale_factor5, None)
  if _44:
    recompute_scale_factor6 = unchecked_cast(bool, recompute_scale_factor5)
    _45 = recompute_scale_factor6
  else:
    _45 = False
  if _45:
    _46 = torch.__isnot__(scale_factors, None)
    if _46:
      scale_factors4 = unchecked_cast(List[float], scale_factors)
      scale_factors3 = scale_factors4
    else:
      ops.prim.RaiseException("AssertionError: ")
      scale_factors3 = _25
    output_size4 = annotate(List[int], [])
    for i in range(dim):
      _47 = torch.size(input, torch.add(i, 2))
      _48 = torch.mul(float(_47), scale_factors3[i])
      _49 = torch.append(output_size4, torch.floor(_48))
    output_size3, scale_factors2 = output_size4, None
  else:
    output_size3, scale_factors2 = output_size, scale_factors
  if antialias:
    _51 = torch.__contains__(["bilinear", "bicubic"], mode)
    if _51:
      _52 = torch.eq(torch.dim(input), 4)
    else:
      _52 = False
    _50 = torch.__not__(_52)
  else:
    _50 = False
  if _50:
    ops.prim.RaiseException(_11)
  else:
    pass
  if torch.eq(torch.dim(input), 3):
    _53 = torch.eq(mode, "nearest")
  else:
    _53 = False
  if _53:
    _55 = torch.upsample_nearest1d(input, output_size3, scale_factors2)
    _54 = _55
  else:
    if torch.eq(torch.dim(input), 4):
      _56 = torch.eq(mode, "nearest")
    else:
      _56 = False
    if _56:
      _58 = torch.upsample_nearest2d(input, output_size3, scale_factors2)
      _57 = _58
    else:
      if torch.eq(torch.dim(input), 5):
        _59 = torch.eq(mode, "nearest")
      else:
        _59 = False
      if _59:
        _61 = torch.upsample_nearest3d(input, output_size3, scale_factors2)
        _60 = _61
      else:
        if torch.eq(torch.dim(input), 3):
          _63 = torch.eq(mode, "nearest-exact")
          _62 = _63
        else:
          _62 = False
        if _62:
          _65 = torch._upsample_nearest_exact1d(input, output_size3, scale_factors2)
          _64 = _65
        else:
          if torch.eq(torch.dim(input), 4):
            _67 = torch.eq(mode, "nearest-exact")
            _66 = _67
          else:
            _66 = False
          if _66:
            _69 = torch._upsample_nearest_exact2d(input, output_size3, scale_factors2)
            _68 = _69
          else:
            _70 = torch.eq(torch.dim(input), 5)
            if _70:
              _72 = torch.eq(mode, "nearest-exact")
              _71 = _72
            else:
              _71 = False
            if _71:
              _74 = torch._upsample_nearest_exact3d(input, output_size3, scale_factors2)
              _73 = _74
            else:
              _75 = torch.eq(torch.dim(input), 3)
              if _75:
                _76 = torch.eq(mode, "area")
              else:
                _76 = False
              if _76:
                _78 = torch.__isnot__(output_size3, None)
                if _78:
                  output_size6 = unchecked_cast(List[int], output_size3)
                  output_size5 = output_size6
                else:
                  ops.prim.RaiseException("AssertionError: ")
                  output_size5 = _22
                _79 = torch.adaptive_avg_pool1d(input, output_size5)
                _77 = _79
              else:
                _80 = torch.eq(torch.dim(input), 4)
                if _80:
                  _82 = torch.eq(mode, "area")
                  _81 = _82
                else:
                  _81 = False
                if _81:
                  _84 = torch.__isnot__(output_size3, None)
                  if _84:
                    output_size8 = unchecked_cast(List[int], output_size3)
                    output_size7 = output_size8
                  else:
                    ops.prim.RaiseException("AssertionError: ")
                    output_size7 = _22
                  _85 = _12(input, output_size7, )
                  _83 = _85
                else:
                  _86 = torch.eq(torch.dim(input), 5)
                  if _86:
                    _88 = torch.eq(mode, "area")
                    _87 = _88
                  else:
                    _87 = False
                  if _87:
                    _90 = torch.__isnot__(output_size3, None)
                    if _90:
                      output_size10 = unchecked_cast(List[int], output_size3)
                      output_size9 = output_size10
                    else:
                      ops.prim.RaiseException("AssertionError: ")
                      output_size9 = _22
                    _91 = _13(input, output_size9, )
                    _89 = _91
                  else:
                    _92 = torch.eq(torch.dim(input), 3)
                    if _92:
                      _94 = torch.eq(mode, "linear")
                      _93 = _94
                    else:
                      _93 = False
                    if _93:
                      _96 = torch.__isnot__(align_corners0, None)
                      if _96:
                        align_corners5 = unchecked_cast(bool, align_corners0)
                        align_corners4 = align_corners5
                      else:
                        ops.prim.RaiseException("AssertionError: ")
                        align_corners4 = _30
                      _97 = torch.upsample_linear1d(input, output_size3, align_corners4, scale_factors2)
                      _95 = _97
                    else:
                      _98 = torch.eq(torch.dim(input), 4)
                      if _98:
                        _100 = torch.eq(mode, "bilinear")
                        _99 = _100
                      else:
                        _99 = False
                      if _99:
                        _102 = torch.__isnot__(align_corners0, None)
                        if _102:
                          align_corners7 = unchecked_cast(bool, align_corners0)
                          align_corners6 = align_corners7
                        else:
                          ops.prim.RaiseException("AssertionError: ")
                          align_corners6 = _30
                        if antialias:
                          _104 = torch._upsample_bilinear2d_aa(input, output_size3, align_corners6, scale_factors2)
                          _103 = _104
                        else:
                          _105 = torch.upsample_bilinear2d(input, output_size3, align_corners6, scale_factors2)
                          _103 = _105
                        _101 = _103
                      else:
                        _106 = torch.dim(input)
                        _107 = torch.eq(_106, 5)
                        if _107:
                          _109 = torch.eq(mode, "trilinear")
                          _108 = _109
                        else:
                          _108 = False
                        if _108:
                          _111 = torch.__isnot__(align_corners0, None)
                          if _111:
                            align_corners9 = unchecked_cast(bool, align_corners0)
                            align_corners8 = align_corners9
                          else:
                            ops.prim.RaiseException("AssertionError: ")
                            align_corners8 = _30
                          _112 = torch.upsample_trilinear3d(input, output_size3, align_corners8, scale_factors2)
                          _110 = _112
                        else:
                          _113 = torch.dim(input)
                          _114 = torch.eq(_113, 4)
                          if _114:
                            _116 = torch.eq(mode, "bicubic")
                            _115 = _116
                          else:
                            _115 = False
                          if _115:
                            _118 = torch.__isnot__(align_corners0, None)
                            if _118:
                              align_corners11 = unchecked_cast(bool, align_corners0)
                              align_corners10 = align_corners11
                            else:
                              ops.prim.RaiseException("AssertionError: ")
                              align_corners10 = _30
                            if antialias:
                              _120 = torch._upsample_bicubic2d_aa(input, output_size3, align_corners10, scale_factors2)
                              _119 = _120
                            else:
                              _121 = torch.upsample_bicubic2d(input, output_size3, align_corners10, scale_factors2)
                              _119 = _121
                            _117 = _119
                          else:
                            _122 = torch.dim(input)
                            _123 = torch.eq(_122, 3)
                            if _123:
                              _125 = torch.eq(mode, "bilinear")
                              _124 = _125
                            else:
                              _124 = False
                            if _124:
                              ops.prim.RaiseException(_14)
                            else:
                              pass
                            _126 = torch.dim(input)
                            _127 = torch.eq(_126, 3)
                            if _127:
                              _129 = torch.eq(mode, "trilinear")
                              _128 = _129
                            else:
                              _128 = False
                            if _128:
                              ops.prim.RaiseException(_15)
                            else:
                              pass
                            _130 = torch.dim(input)
                            _131 = torch.eq(_130, 4)
                            if _131:
                              _133 = torch.eq(mode, "linear")
                              _132 = _133
                            else:
                              _132 = False
                            if _132:
                              ops.prim.RaiseException(_16)
                            else:
                              pass
                            _134 = torch.dim(input)
                            _135 = torch.eq(_134, 4)
                            if _135:
                              _137 = torch.eq(mode, "trilinear")
                              _136 = _137
                            else:
                              _136 = False
                            if _136:
                              ops.prim.RaiseException(_17)
                            else:
                              pass
                            _138 = torch.dim(input)
                            _139 = torch.eq(_138, 5)
                            if _139:
                              _141 = torch.eq(mode, "linear")
                              _140 = _141
                            else:
                              _140 = False
                            if _140:
                              ops.prim.RaiseException(_18)
                            else:
                              pass
                            _142 = torch.dim(input)
                            _143 = torch.eq(_142, 5)
                            if _143:
                              _145 = torch.eq(mode, "bilinear")
                              _144 = _145
                            else:
                              _144 = False
                            if _144:
                              ops.prim.RaiseException(_19)
                            else:
                              pass
                            _146 = torch.dim(input)
                            _147 = torch.format(_20, _146, mode)
                            ops.prim.RaiseException(_147)
                            _117 = _21
                          _110 = _117
                        _101 = _110
                      _95 = _101
                    _89 = _95
                  _83 = _89
                _77 = _83
              _73 = _77
            _68 = _73
          _64 = _68
        _60 = _64
      _57 = _60
    _54 = _57
  return _54
def dropout3d(input: Tensor,
    p: float=0.5,
    training: bool=True,
    inplace: bool=False) -> Tensor:
  _148 = "dropout probability has to be between 0 and 1, but got {}"
  _149 = "dropout3d: Received a {}-D input to dropout3d, which is deprecated and will result in an error in a future release. To retain the behavior and silence this warning, please use dropout instead. Note that dropout3d exists to provide channel-wise dropout on inputs with 3 spatial dimensions, a channel dimension, and an optional batch dimension (i.e. 4D or 5D inputs)."
  if torch.lt(p, 0.):
    _150 = True
  else:
    _150 = torch.gt(p, 1.)
  if _150:
    ops.prim.RaiseException(torch.format(_148, p))
  else:
    pass
  inp_dim = torch.dim(input)
  _151 = torch.__not__(torch.__contains__([4, 5], inp_dim))
  if _151:
    warn_msg = torch.format(_149, inp_dim)
    torch.warn(warn_msg)
  else:
    pass
  is_batched = torch.eq(inp_dim, 5)
  if torch.__not__(is_batched):
    if inplace:
      input1 = torch.unsqueeze_(input, 0)
    else:
      input1 = torch.unsqueeze(input, 0)
    input0 = input1
  else:
    input0 = input
  if inplace:
    _152 = torch.feature_dropout_(input0, p, training)
    result = _152
  else:
    _153 = torch.feature_dropout(input0, p, training)
    result = _153
  if torch.__not__(is_batched):
    if inplace:
      result1 = torch.squeeze_(result, 0)
    else:
      result1 = torch.squeeze(result, 0)
    result0 = result1
  else:
    result0 = result
  return result0
def _verify_batch_size(size: List[int]) -> NoneType:
  _154 = "Expected more than 1 value per channel when training, got input size {}"
  size_prods = size[0]
  size_prods0 = size_prods
  for i in range(torch.sub(torch.len(size), 2)):
    size_prods1 = torch.mul(size_prods0, size[torch.add(i, 2)])
    size_prods0 = size_prods1
  if torch.eq(size_prods0, 1):
    ops.prim.RaiseException(torch.format(_154, size))
  else:
    pass
  return None
def adaptive_avg_pool2d(input: Tensor,
    output_size: List[int]) -> Tensor:
  _155 = torch.gt(torch.len(torch.size(input)), torch.len(output_size))
  if _155:
    pass
  else:
    ops.prim.RaiseException("AssertionError: ")
  _156 = torch.adaptive_avg_pool2d(input, output_size)
  return _156
def adaptive_avg_pool3d(input: Tensor,
    output_size: List[int]) -> Tensor:
  _157 = torch.gt(torch.len(torch.size(input)), torch.len(output_size))
  if _157:
    pass
  else:
    ops.prim.RaiseException("AssertionError: ")
  _158 = torch.adaptive_avg_pool3d(input, output_size)
  return _158
