class GroupNorm(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : NoneType
  affine : Final[bool] = True
  num_groups : Final[int] = 8
  num_channels : Final[int] = 128
  eps : Final[float] = 1.0000000000000001e-05
  def forward(self: __torch__.torch.nn.modules.normalization.___torch_mangle_18.GroupNorm,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.group_norm
    weight = self.weight
    bias = self.bias
    _1 = _0(input, 8, weight, bias, 1.0000000000000001e-05, )
    return _1
