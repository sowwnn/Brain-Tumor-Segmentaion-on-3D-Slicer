class Upsample(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  name : Final[str] = "Upsample"
  scale_factor : Final[Tuple[float, float, float]] = (2., 2., 2.)
  size : Final[NoneType] = None
  recompute_scale_factor : Final[NoneType] = None
  align_corners : Final[bool] = False
  mode : Final[str] = "trilinear"
  def forward(self: __torch__.torch.nn.modules.upsampling.Upsample,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.interpolate
    _1 = _0(input, None, [2., 2., 2.], "trilinear", False, None, False, )
    return _1
