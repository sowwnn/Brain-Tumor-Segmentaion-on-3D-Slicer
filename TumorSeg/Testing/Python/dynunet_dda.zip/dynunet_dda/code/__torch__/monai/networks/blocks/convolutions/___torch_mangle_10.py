class Convolution(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  spatial_dims : int
  in_channels : int
  out_channels : int
  is_transposed : bool
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_9.Conv3d
  def forward(self: __torch__.monai.networks.blocks.convolutions.___torch_mangle_10.Convolution,
    input: Tensor) -> Tensor:
    conv = self.conv
    return (conv).forward(input, )
  def __len__(self: __torch__.monai.networks.blocks.convolutions.___torch_mangle_10.Convolution) -> int:
    return 1
