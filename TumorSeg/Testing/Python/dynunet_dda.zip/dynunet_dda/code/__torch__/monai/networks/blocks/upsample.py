class UpSample(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  upsample_non_trainable : __torch__.torch.nn.modules.upsampling.Upsample
  def forward(self: __torch__.monai.networks.blocks.upsample.UpSample,
    input: Tensor) -> Tensor:
    upsample_non_trainable = self.upsample_non_trainable
    input0 = (upsample_non_trainable).forward(input, )
    return input0
  def __len__(self: __torch__.monai.networks.blocks.upsample.UpSample) -> int:
    return 1
