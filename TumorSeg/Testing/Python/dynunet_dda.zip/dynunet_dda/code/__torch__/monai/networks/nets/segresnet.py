class SegResNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  spatial_dims : int
  init_filters : int
  in_channels : int
  blocks_down : List[int]
  blocks_up : List[int]
  dropout_prob : float
  act : Tuple[str, Dict[str, bool]]
  norm : Tuple[str, Dict[str, int]]
  upsample_mode : str
  use_conv_final : bool
  act_mod : __torch__.torch.nn.modules.activation.ReLU
  convInit : __torch__.monai.networks.blocks.convolutions.Convolution
  down_layers : __torch__.torch.nn.modules.container.ModuleList
  up_layers : __torch__.torch.nn.modules.container.___torch_mangle_26.ModuleList
  up_samples : __torch__.torch.nn.modules.container.___torch_mangle_36.ModuleList
  conv_final : __torch__.torch.nn.modules.container.___torch_mangle_39.Sequential
  dropout : __torch__.torch.nn.modules.dropout.Dropout3d
  def forward(self: __torch__.monai.networks.nets.segresnet.SegResNet,
    x: Tensor) -> Tensor:
    x0, down_x, = (self).encode(x, )
    torch.reverse(down_x)
    return (self).decode(x0, down_x, )
  def encode(self: __torch__.monai.networks.nets.segresnet.SegResNet,
    x: Tensor) -> Tuple[Tensor, List[Tensor]]:
    convInit = self.convInit
    x1 = (convInit).forward(x, )
    dropout = self.dropout
    x2 = (dropout).forward(x1, )
    down_x = annotate(List[Tensor], [])
    down_layers = self.down_layers
    _0 = getattr(down_layers, "0")
    _1 = getattr(down_layers, "1")
    _2 = getattr(down_layers, "2")
    _3 = getattr(down_layers, "3")
    x3 = (_0).forward(x2, )
    _4 = torch.append(down_x, x3)
    x4 = (_1).forward(x3, )
    _5 = torch.append(down_x, x4)
    x5 = (_2).forward(x4, )
    _6 = torch.append(down_x, x5)
    x6 = (_3).forward(x5, )
    _7 = torch.append(down_x, x6)
    return (x6, down_x)
  def decode(self: __torch__.monai.networks.nets.segresnet.SegResNet,
    x: Tensor,
    down_x: List[Tensor]) -> Tensor:
    up_samples = self.up_samples
    _0 = getattr(up_samples, "0")
    _1 = getattr(up_samples, "1")
    _2 = getattr(up_samples, "2")
    up_layers = self.up_layers
    _08 = getattr(up_layers, "0")
    _17 = getattr(up_layers, "1")
    _26 = getattr(up_layers, "2")
    x7 = torch.add((_0).forward(x, ), down_x[1])
    x8 = (_08).forward(x7, )
    x9 = torch.add((_1).forward(x8, ), down_x[2])
    x10 = (_17).forward(x9, )
    x11 = torch.add((_2).forward(x10, ), down_x[3])
    x12 = (_26).forward(x11, )
    use_conv_final = self.use_conv_final
    if use_conv_final:
      conv_final = self.conv_final
      x13 = (conv_final).forward(x12, )
    else:
      x13 = x12
    return x13
