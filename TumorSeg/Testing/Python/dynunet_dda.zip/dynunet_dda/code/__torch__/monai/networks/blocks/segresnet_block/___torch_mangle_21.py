class ResBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.normalization.___torch_mangle_18.GroupNorm
  norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_18.GroupNorm
  act : __torch__.torch.nn.modules.activation.ReLU
  conv1 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_20.Convolution
  conv2 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_20.Convolution
  def forward(self: __torch__.monai.networks.blocks.segresnet_block.___torch_mangle_21.ResBlock,
    x: Tensor) -> Tensor:
    norm1 = self.norm1
    x0 = (norm1).forward(x, )
    act = self.act
    x1 = (act).forward(x0, )
    conv1 = self.conv1
    x2 = (conv1).forward(x1, )
    norm2 = self.norm2
    x3 = (norm2).forward(x2, )
    act0 = self.act
    x4 = (act0).forward(x3, )
    conv2 = self.conv2
    x5 = (conv2).forward(x4, )
    return torch.add_(x5, x)
